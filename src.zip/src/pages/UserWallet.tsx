import React, { useState, useEffect } from 'react';

interface Transaction {
  id: string;
  amountUSD: number;
  amountCDF: number;
  type: string;
  status: string;
  provider?: string;
  createdAt: string;
}

interface WalletData {
  balanceUSD: number;
  balanceCDF: number;
  transactions: Transaction[];
}

export default function UserWallet() {
  const [wallet, setWallet] = useState<WalletData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // États pour le Dépôt
  const [depositAmount, setDepositAmount] = useState<string>('');
  const [depositCurrency, setDepositCurrency] = useState<string>('USD');
  const [depositProvider, setDepositProvider] = useState<string>('MPESA');
  const [depositPhone, setDepositPhone] = useState<string>('');
  const [depositing, setDepositing] = useState<boolean>(false);
  const [depositMsg, setDepositMsg] = useState<{ text: string; success: boolean } | null>(null);

  // États pour le Retrait
  const [withdrawAmount, setWithdrawAmount] = useState<string>('');
  const [withdrawCurrency, setWithdrawCurrency] = useState<string>('USD');
  const [withdrawProvider, setWithdrawProvider] = useState<string>('MPESA');
  const [withdrawPhone, setWithdrawPhone] = useState<string>('');
  const [withdrawing, setWithdrawing] = useState<boolean>(false);
  const [withdrawMsg, setWithdrawMsg] = useState<{ text: string; success: boolean } | null>(null);

  const token = localStorage.getItem('token');

  const fetchWallet = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/wallet', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      if (response.ok) {
        setWallet(data.data || data);
      } else {
        setError(data.message || 'Erreur lors du chargement.');
      }
    } catch (err) {
      setError('Impossible de se connecter au serveur.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWallet();
  }, []);

  // Action Dépôt
  const handleDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    setDepositing(true);
    setDepositMsg(null);

    try {
      const response = await fetch('/api/wallet/deposit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          amount: parseFloat(depositAmount),
          currency: depositCurrency,
          provider: depositProvider,
          phoneNumber: depositPhone
        })
      });

      const data = await response.json();
      if (response.ok) {
        setDepositMsg({ text: 'Dépôt initié avec succès ! Vérifiez votre téléphone.', success: true });
        setDepositAmount('');
        setDepositPhone('');
        fetchWallet();
      } else {
        setDepositMsg({ text: data.message || 'Erreur lors du dépôt.', success: false });
      }
    } catch (err) {
      setDepositMsg({ text: 'Erreur réseau.', success: false });
    } finally {
      setDepositing(false);
    }
  };

  // Action Retrait
  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawing(true);
    setWithdrawMsg(null);

    try {
      const response = await fetch('/api/wallet/withdraw', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          amount: parseFloat(withdrawAmount),
          currency: withdrawCurrency,
          provider: withdrawProvider,
          phoneNumber: withdrawPhone
        })
      });

      const data = await response.json();
      if (response.ok) {
        setWithdrawMsg({ text: 'Demande de retrait envoyée avec succès !', success: true });
        setWithdrawAmount('');
        setWithdrawPhone('');
        fetchWallet();
      } else {
        setWithdrawMsg({ text: data.message || 'Erreur lors du retrait.', success: false });
      }
    } catch (err) {
      setWithdrawMsg({ text: 'Erreur réseau.', success: false });
    } finally {
      setWithdrawing(false);
    }
  };

  if (loading) {
    return <div className="p-6 text-neutral-400">Chargement de votre portefeuille...</div>;
  }

  if (error) {
    return (
      <div className="p-6 bg-neutral-800 rounded-lg">
        <p className="text-red-400">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Cartes des soldes */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-neutral-800 border border-neutral-700 p-6 rounded-xl shadow-lg">
          <p className="text-sm text-neutral-400">Solde en Dollars (USD)</p>
          <p className="text-3xl font-extrabold text-green-400 mt-2">
            ${wallet?.balanceUSD?.toFixed(2) || '0.00'}
          </p>
        </div>
        <div className="bg-neutral-800 border border-neutral-700 p-6 rounded-xl shadow-lg">
          <p className="text-sm text-neutral-400">Solde en Francs Congolais (CDF)</p>
          <p className="text-3xl font-extrabold text-orange-400 mt-2">
            {wallet?.balanceCDF?.toLocaleString() || '0'} CDF
          </p>
        </div>
      </div>

      {/* Grille : Formulaire de Dépôt & Formulaire de Retrait */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* BLOC DÉPÔT */}
        <div className="bg-neutral-800 border border-neutral-700 p-6 rounded-xl shadow-lg">
          <h3 className="text-lg font-bold text-green-400 mb-4">📥 Faire un Dépôt</h3>
          {depositMsg && (
            <div className={`mb-4 p-3 rounded text-sm ${depositMsg.success ? 'bg-green-900/50 text-green-300' : 'bg-red-900/50 text-red-300'}`}>
              {depositMsg.text}
            </div>
          )}
          <form onSubmit={handleDeposit} className="space-y-3">
            <div>
              <label className="block text-xs text-neutral-400 mb-1">Montant</label>
              <input 
                type="number" 
                value={depositAmount} 
                onChange={(e) => setDepositAmount(e.target.value)} 
                placeholder="Ex: 20" 
                required
                className="w-full bg-neutral-900 border border-neutral-700 rounded p-2 text-sm text-white focus:outline-none focus:border-orange-500"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs text-neutral-400 mb-1">Devise</label>
                <select 
                  value={depositCurrency} 
                  onChange={(e) => setDepositCurrency(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded p-2 text-sm text-white focus:outline-none focus:border-orange-500"
                >
                  <option value="USD">USD ($)</option>
                  <option value="CDF">CDF (FC)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-neutral-400 mb-1">Opérateur</label>
                <select 
                  value={depositProvider} 
                  onChange={(e) => setDepositProvider(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded p-2 text-sm text-white focus:outline-none focus:border-orange-500"
                >
                  <option value="MPESA">M-Pesa</option>
                  <option value="ORANGE_MONEY">Orange Money</option>
                  <option value="AIRTEL_MONEY">Airtel Money</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-xs text-neutral-400 mb-1">Numéro de téléphone</label>
              <input 
                type="text" 
                value={depositPhone} 
                onChange={(e) => setDepositPhone(e.target.value)} 
                placeholder="Ex: +243..." 
                required
                className="w-full bg-neutral-900 border border-neutral-700 rounded p-2 text-sm text-white focus:outline-none focus:border-orange-500"
              />
            </div>
            <button 
              type="submit" 
              disabled={depositing}
              className="w-full bg-green-600 hover:bg-green-500 text-white font-semibold py-2 rounded text-sm transition cursor-pointer disabled:opacity-50 mt-2"
            >
              {depositing ? 'Traitement...' : 'Valider le dépôt'}
            </button>
          </form>
        </div>

        {/* BLOC RETRAIT */}
        <div className="bg-neutral-800 border border-neutral-700 p-6 rounded-xl shadow-lg">
          <h3 className="text-lg font-bold text-orange-400 mb-4">📤 Faire un Retrait</h3>
          {withdrawMsg && (
            <div className={`mb-4 p-3 rounded text-sm ${withdrawMsg.success ? 'bg-green-900/50 text-green-300' : 'bg-red-900/50 text-red-300'}`}>
              {withdrawMsg.text}
            </div>
          )}
          <form onSubmit={handleWithdraw} className="space-y-3">
            <div>
              <label className="block text-xs text-neutral-400 mb-1">Montant</label>
              <input 
                type="number" 
                value={withdrawAmount} 
                onChange={(e) => setWithdrawAmount(e.target.value)} 
                placeholder="Ex: 10" 
                required
                className="w-full bg-neutral-900 border border-neutral-700 rounded p-2 text-sm text-white focus:outline-none focus:border-orange-500"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs text-neutral-400 mb-1">Devise</label>
                <select 
                  value={withdrawCurrency} 
                  onChange={(e) => setWithdrawCurrency(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded p-2 text-sm text-white focus:outline-none focus:border-orange-500"
                >
                  <option value="USD">USD ($)</option>
                  <option value="CDF">CDF (FC)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-neutral-400 mb-1">Opérateur</label>
                <select 
                  value={withdrawProvider} 
                  onChange={(e) => setWithdrawProvider(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded p-2 text-sm text-white focus:outline-none focus:border-orange-500"
                >
                  <option value="MPESA">M-Pesa</option>
                  <option value="ORANGE_MONEY">Orange Money</option>
                  <option value="AIRTEL_MONEY">Airtel Money</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-xs text-neutral-400 mb-1">Numéro de téléphone</label>
              <input 
                type="text" 
                value={withdrawPhone} 
                onChange={(e) => setWithdrawPhone(e.target.value)} 
                placeholder="Ex: +243..." 
                required
                className="w-full bg-neutral-900 border border-neutral-700 rounded p-2 text-sm text-white focus:outline-none focus:border-orange-500"
              />
            </div>
            <button 
              type="submit" 
              disabled={withdrawing}
              className="w-full bg-orange-600 hover:bg-orange-500 text-white font-semibold py-2 rounded text-sm transition cursor-pointer disabled:opacity-50 mt-2"
            >
              {withdrawing ? 'Traitement...' : 'Valider le retrait'}
            </button>
          </form>
        </div>

      </div>

      {/* Historique des transactions */}
      <div className="bg-neutral-800 border border-neutral-700 p-6 rounded-xl shadow-lg">
        <h3 className="text-xl font-semibold mb-4 text-white">Historique des transactions</h3>
        {wallet?.transactions && wallet.transactions.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-neutral-700 text-neutral-400">
                  <th className="pb-3">Type</th>
                  <th className="pb-3">Montant USD</th>
                  <th className="pb-3">Montant CDF</th>
                  <th className="pb-3">Statut</th>
                  <th className="pb-3">Date</th>
                </tr>
              </thead>
              <tbody>
                {wallet.transactions.map((tx) => (
                  <tr key={tx.id} className="border-b border-neutral-700/50">
                    <td className="py-3 font-medium text-white">{tx.type}</td>
                    <td className="py-3 text-green-400">${tx.amountUSD}</td>
                    <td className="py-3 text-orange-400">{tx.amountCDF} CDF</td>
                    <td className="py-3">
                      <span className={`px-2 py-1 rounded text-xs ${
                        tx.status === 'SUCCESS' ? 'bg-green-900 text-green-300' : 
                        tx.status === 'PENDING' ? 'bg-yellow-900 text-yellow-300' : 'bg-red-900 text-red-300'
                      }`}>
                        {tx.status}
                      </span>
                    </td>
                    <td className="py-3 text-neutral-400">{new Date(tx.createdAt).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-neutral-400 text-sm">Aucune transaction pour le moment.</p>
        )}
      </div>
    </div>
  );
}