import React, { useEffect, useState } from 'react';
import axios from 'axios';

interface Order {
  id: string;
  status: string;
  totalCDF: number;
  totalUSD: number;
  createdAt: string;
}

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('http://localhost:5000/api/orders', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setOrders(res.data);
      } catch (err: any) {
        setError("Impossible de charger vos commandes.");
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, []);

  if (loading) {
    return <div className="max-w-7xl mx-auto px-4 py-8 text-white">Chargement de vos commandes...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 text-white">
      <h1 className="text-2xl font-bold mb-6">Mes Commandes</h1>
      
      {error && <p className="text-red-500 mb-4">{error}</p>}

      {orders.length === 0 ? (
        <p className="text-neutral-400">Vous n'avez passé aucune commande pour le moment.</p>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => (
            <div key={order.id} className="bg-neutral-900 border border-neutral-800 p-4 rounded-xl flex justify-between items-center">
              <div>
                <p className="font-semibold text-primary-400">Commande #{order.id.slice(0, 8)}</p>
                <p className="text-sm text-neutral-400">Date : {new Date(order.createdAt).toLocaleDateString()}</p>
                <p className="text-sm">Statut : <span className="font-medium text-yellow-500">{order.status}</span></p>
              </div>
              <div className="text-right">
                <p className="font-bold">{order.totalUSD} USD</p>
                <p className="text-xs text-neutral-400">({order.totalCDF} CDF)</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}