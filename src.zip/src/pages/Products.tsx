import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link, useSearchParams } from 'react-router-dom';
import { Search, ShoppingBag, ArrowLeft, Sun, Moon } from 'lucide-react';

export default function Products() {
  const [searchParams] = useSearchParams();
  const initialSearch = searchParams.get('search') || '';
  const initialCategory = searchParams.get('category') || 'Tous';

  const [darkMode, setDarkMode] = useState(true);
  const [searchTerm, setSearchTerm] = useState(initialSearch);
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);

  const products = [
    { id: 1, name: "Smartphone Infinix Hot 30", price: "185 $", category: "Téléphonie", location: "Ibanda, Bukavu", image: "https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=500&q=80" },
    { id: 2, name: "Ordinateur Portable HP Core i5", price: "320 $", category: "Informatique", location: "Kadutu, Bukavu", image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=500&q=80" },
    { id: 3, name: "Paire de Sneakers Nike Air Max", price: "45 $", category: "Mode & Vêtements", location: "Place de l'Indépendance", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=500&q=80" },
    { id: 4, name: "Générateur Électronique Portable", price: "450 $", category: "Équipement", location: "Bagira, Bukavu", image: "https://images.unsplash.com/photo-1590502593747-42a96f669e72?auto=format&fit=crop&w=500&q=80" },
  ];

  const categories = ["Tous", "Téléphonie", "Informatique", "Mode & Vêtements", "Équipement"];

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'Tous' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-neutral-950 text-white' : 'bg-neutral-50 text-neutral-900'}`}>
      
      {/* HEADER */}
      <header className={`sticky top-0 z-50 border-b px-4 lg:px-8 py-3 transition-colors ${
        darkMode ? 'bg-neutral-900/90 border-neutral-800 backdrop-blur-md' : 'bg-white/90 border-neutral-200 backdrop-blur-md'
      }`}>
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-10 h-10 bg-orange-600 rounded-xl flex items-center justify-center text-white font-black text-base shadow-lg shadow-orange-600/30">
              CBF
            </div>
            <div>
              <span className="font-extrabold text-base tracking-tight block leading-none">CBFSOKO</span>
              <span className="text-[10px] text-orange-500 font-bold tracking-widest uppercase">Bukavu</span>
            </div>
          </Link>
          
          <div className="flex items-center gap-3">
            <Link to="/" className="text-xs font-semibold text-neutral-400 hover:text-white flex items-center gap-1 transition">
              <ArrowLeft className="w-4 h-4" /> Accueil
            </Link>
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`p-2.5 rounded-xl border transition flex items-center justify-center cursor-pointer ${
                darkMode ? 'bg-neutral-950 border-neutral-800 text-yellow-400' : 'bg-white border-neutral-300 text-neutral-800'
              }`}
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4 text-orange-600" />}
            </button>
          </div>
        </div>
      </header>

      {/* CONTENU PRINCIPAL */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-black tracking-tight">Catalogue des produits</h1>
            <p className="text-xs text-neutral-400 mt-1">Trouvez les meilleures offres disponibles à Bukavu et au Sud-Kivu[cite: 4].</p>
          </div>

          <div className={`flex items-center w-full md:w-80 rounded-xl border px-3 py-2.5 transition ${
            darkMode ? 'bg-neutral-900 border-neutral-800 focus-within:border-orange-500' : 'bg-white border-neutral-300 focus-within:border-orange-500'
          }`}>
            <Search className="w-4 h-4 text-neutral-500 mr-2" />
            <input 
              type="text" 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Rechercher un produit..."
              className="w-full bg-transparent text-xs outline-none"
            />
          </div>
        </div>

        {/* CATÉGORIES */}
        <div className="flex gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                selectedCategory === cat 
                  ? 'bg-orange-600 text-white shadow-lg shadow-orange-600/20' 
                  : darkMode ? 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800' : 'bg-white text-neutral-600 hover:text-black border border-neutral-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* GRILLE DE PRODUITS AVEC ANIMATIONS */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {filteredProducts.map((product, index) => (
              <motion.div 
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                className={`rounded-2xl overflow-hidden border group shadow-md transition ${
                  darkMode ? 'bg-neutral-900 border-neutral-800' : 'bg-white border-neutral-200'
                }`}
              >
                <div className="h-48 overflow-hidden bg-neutral-950 relative">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  />
                  <span className="absolute top-3 left-3 bg-black/80 backdrop-blur-md text-[10px] font-bold px-2.5 py-1 rounded-md text-orange-400 border border-neutral-700">
                    {product.category}
                  </span>
                </div>
                <div className="p-4">
                  <p className="text-[11px] text-neutral-500 mb-1">{product.location}</p>
                  <h3 className="font-bold text-sm mb-3 truncate">{product.name}</h3>
                  <div className="flex justify-between items-center">
                    <span className="text-base font-black text-orange-500">{product.price}</span>
                    <button 
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                        darkMode ? 'bg-neutral-800 hover:bg-orange-600 hover:text-white text-neutral-200' : 'bg-neutral-100 hover:bg-orange-600 hover:text-white text-neutral-800'
                      }`}
                    >
                      Détails
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={`border rounded-2xl p-12 text-center ${
              darkMode ? 'border-neutral-800 bg-neutral-900/50 text-neutral-400' : 'border-neutral-200 bg-white text-neutral-600'
            }`}
          >
            <ShoppingBag className="w-12 h-12 mx-auto mb-3 text-neutral-500 opacity-50" />
            <p className="text-sm font-semibold">Aucun produit ne correspond à votre recherche</p>
            <button 
              onClick={() => { setSearchTerm(''); setSelectedCategory('Tous'); }}
              className="mt-4 px-4 py-2 bg-orange-600 text-white rounded-xl text-xs font-bold transition hover:bg-orange-700 cursor-pointer"
            >
              Réinitialiser les filtres
            </button>
          </motion.div>
        )}
      </div>
    </div>
  );
}