import { Link, useNavigate } from 'react-router-dom';
import React from 'react';

export default function Notifications() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8 text-white">
      <h1 className="text-2xl font-bold mb-4">Mes Notifications</h1>
      <p>Aucune notification pour le moment.</p>
    </div>
  );
}