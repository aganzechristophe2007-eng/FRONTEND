import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { Search, PlusCircle, Store, Sun, Moon, ArrowRight, Zap, Wallet } from 'lucide-react';
import { apiFetch } from '../api/client';

interface ProductItem {
  id: string;
  title?: string;
  name?: string;
  priceUSD?: number;
  price?: string | number;
  category?: { name: string } | string;
  location?: string;
  images?: string[];
  image?: string;
}

export default function Home() {
  const [darkMode, setDarkMode] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [user, setUser] = useState<{ name: string; balance: number } | null>(null);
  const [featuredProducts, setFeaturedProducts] = useState<ProductItem[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    // 1. Récupérer l'utilisateur stocké et tenter de rafraîchir ses infos (solde)
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (e) {
        console.error("Erreur de lecture utilisateur", e);
      }
    }

    // Optionnel : vérifier le profil en arrière-plan pour avoir le solde à jour
    const token = localStorage.getItem('token');
    if (token) {
      apiFetch('/auth/me')
        .then(userData => {
          if (userData) {
            setUser(userData);
            localStorage.setItem('user', JSON.stringify(userData));
          }
        })
        .catch(() => {
          // Si le token est invalide, on nettoie proprement
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          setUser(null);
        });
    }

    // 2. Charger les vrais produits récents depuis l'API pour les Hot Products
    apiFetch('/products')
      .then(data => {
        const list = Array.isArray(data) ? data : (data.data || []);
        // On prend les 4 derniers produits ajoutés
        setFeaturedProducts(list.slice(0, 4));
      })
      .catch(err => {
        console.error("Impossible de charger les produits récents", err);
      })
      .finally(() => {
        setLoadingProducts(false);
      });
  }, []);

  const getInitials = (name: string) => {
    if (!name) return "U";
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  const handleProtectedAction = (destination: string) => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate(`/login?redirect=${destination}`);
    } else {
      navigate(destination);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery)}`);
    } else {
      navigate('/products');
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-neutral-950 text-white' : 'bg-neutral-50 text-neutral-900'}`}>
      
      {/* HEADER PRINCIPAL AVEC BARRE DE RECHERCHE INTÉGRÉE */}
      <header className={`sticky top-0 z-50 border-b px-4 lg:px-8 py-3 transition-colors ${
        darkMode ? 'bg-neutral-900/90 border-neutral-800 backdrop-blur-md' : 'bg-white/90 border-neutral-200 backdrop-blur-md'
      }`}>
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          
          <Link to="/" className="flex items-center gap-2.5 flex-shrink-0">
            <div className="w-10 h-10 bg-orange-600 rounded-xl flex items-center justify-center text-white font-black text-base shadow-lg shadow-orange-600/30">
              CBF
            </div>
            <div>
              <span className="font-extrabold text-base tracking-tight block leading-none">CBFSOKO</span>
              <span className="text-[10px] text-orange-500 font-bold tracking-widest uppercase">Bukavu</span>
            </div>
          </Link>

          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-xl mx-4">
            <div className={`flex w-full items-center rounded-xl border overflow-hidden transition ${
              darkMode ? 'bg-neutral-950 border-neutral-800 focus-within:border-orange-500' : 'bg-neutral-100 border-neutral-300 focus-within:border-orange-500'
            }`}>
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Rechercher un produit, une marque à Bukavu..." 
                className="w-full bg-transparent px-4 py-2.5 text-xs sm:text-sm outline-none placeholder-neutral-500"
              />
              <button type="submit" className="bg-orange-600 hover:bg-orange-700 px-5 py-2.5 text-white transition flex items-center justify-center cursor-pointer">
                <Search className="w-4 h-4" />
              </button>
            </div>
          </form>

          <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
            <button 
              onClick={() => handleProtectedAction('/create-product')}
              className="flex items-center gap-1.5 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs sm:text-sm px-3.5 py-2.5 rounded-xl transition shadow-md shadow-orange-600/20 cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span className="hidden sm:inline">Poster</span>
            </button>

            <button 
              onClick={() => handleProtectedAction('/shop-dashboard')}
              className={`hidden lg:flex items-center gap-1.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition border cursor-pointer ${
                darkMode ? 'bg-neutral-950 border-neutral-800 text-neutral-300 hover:text-white' : 'bg-neutral-100 border-neutral-300 text-neutral-700 hover:text-black'
              }`}
            >
              <Store className="w-4 h-4 text-orange-500" />
              <span>Boutique</span>
            </button>

            {/* SECTION AUTH / UTILISATEUR CONNECTÉ (Solde cliquable vers le Wallet) */}
            {user ? (
              <button 
                onClick={() => handleProtectedAction('/wallet')}
                className={`flex items-center gap-2.5 px-3 py-1.5 rounded-xl border transition group cursor-pointer ${
                  darkMode ? 'bg-neutral-950 border-neutral-800 hover:border-orange-500 text-white' : 'bg-white border-neutral-300 hover:border-orange-500 text-neutral-900'
                }`}
                title="Cliquer pour recharger votre solde"
              >
                <div className="w-8 h-8 rounded-full bg-orange-600 text-white font-bold text-xs flex items-center justify-center shadow group-hover:scale-105 transition">
                  {getInitials(user.name)}
                </div>
                <div className="hidden sm:flex flex-col text-left">
                  <span className="text-[10px] text-neutral-400 leading-none flex items-center gap-1">
                    Solde <Wallet className="w-3 h-3 text-orange-500" />
                  </span>
                  <span className="text-xs font-black text-orange-500">{user.balance ?? 0} $</span>
                </div>
              </button>
            ) : (
              <Link 
                to="/login"
                className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-orange-600 hover:bg-orange-700 text-white transition shadow-md shadow-orange-600/20"
              >
                Connexion
              </Link>
            )}

            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`p-2.5 rounded-xl border transition flex items-center justify-center cursor-pointer ${
                darkMode ? 'bg-neutral-950 border-neutral-800 text-yellow-400' : 'bg-white border-neutral-300 text-neutral-800'
              }`}
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4 text-orange-600" />}
            </button>
          </div>

        </div>
      </header>

      {/* BANNIÈRES PROMOTIONNELLES / CATÉGORIES */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          
          <div className="relative rounded-2xl overflow-hidden group h-44 bg-gradient-to-r from-red-950 to-neutral-900 border border-neutral-800 p-6 flex flex-col justify-between shadow-lg">
            <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-red-600/20 rounded-full blur-2xl group-hover:bg-red-600/30 transition"></div>
            <div>
              <span className="bg-red-600 text-white text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-md">Promo Kivu</span>
              <h3 className="text-xl font-black mt-2 text-white">Laptop Collection</h3>
            </div>
            <Link to="/products?category=Informatique" className="inline-flex items-center gap-1 text-xs font-bold text-red-400 hover:text-red-300 transition">
              Voir tout <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="relative rounded-2xl overflow-hidden group h-44 bg-gradient-to-r from-orange-950 to-neutral-900 border border-neutral-800 p-6 flex flex-col justify-between shadow-lg">
            <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-orange-600/20 rounded-full blur-2xl group-hover:bg-orange-600/30 transition"></div>
            <div>
              <span className="bg-orange-600 text-white text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-md">Tendance</span>
              <h3 className="text-xl font-black mt-2 text-white">Smartphone & High-Tech</h3>
            </div>
            <Link to="/products?category=Téléphonie" className="inline-flex items-center gap-1 text-xs font-bold text-orange-400 hover:text-orange-300 transition">
              Voir tout <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="relative rounded-2xl overflow-hidden group h-44 bg-gradient-to-r from-neutral-900 to-neutral-800 border border-neutral-800 p-6 flex flex-col justify-between shadow-lg">
            <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-neutral-600/20 rounded-full blur-2xl group-hover:bg-neutral-600/30 transition"></div>
            <div>
              <span className="bg-neutral-700 text-white text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-md">Équipement</span>
              <h3 className="text-xl font-black mt-2 text-white">Énergie & Maison</h3>
            </div>
            <Link to="/products?category=Équipement" className="inline-flex items-center gap-1 text-xs font-bold text-neutral-300 hover:text-white transition">
              Voir tout <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

        </div>
      </div>

      {/* SECTION HOT PRODUCTS (Dynamique) */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6 border-b border-neutral-800 pb-4">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-orange-500" />
            <h2 className="text-2xl font-extrabold tracking-tight">HOT PRODUCTS</h2>
          </div>
          <Link to="/products" className="text-orange-500 hover:text-orange-400 font-semibold text-xs uppercase tracking-wider transition">
            Catalogue complet &rarr;
          </Link>
        </div>

        {loadingProducts ? (
          <div className="text-center py-12 text-neutral-500 text-xs flex flex-col items-center justify-center gap-3">
            <div className="w-6 h-6 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
            Chargement des nouveautés...
          </div>
        ) : featuredProducts.length === 0 ? (
          <div className="text-center py-12 text-neutral-500 text-xs">
            Aucun produit disponible pour le moment. Soyez le premier à en poster un !
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {featuredProducts.map((product, index) => {
              const prodTitle = product.title || product.name || 'Article sans nom';
              const prodPrice = product.priceUSD !== undefined ? `${product.priceUSD} $` : (product.price ? `${product.price} $` : 'Prix sur demande');
              const prodCategory = typeof product.category === 'object' && product.category !== null ? product.category.name : (product.category || 'Général');
              const prodImage = (product.images && product.images.length > 0) ? product.images[0] : (product.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=500&q=80');

              return (
                <motion.div 
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  className={`rounded-2xl overflow-hidden border group shadow-md transition ${
                    darkMode ? 'bg-neutral-900 border-neutral-800' : 'bg-white border-neutral-200'
                  }`}
                >
                  <div className="h-48 overflow-hidden bg-neutral-950 relative">
                    <img 
                      src={prodImage} 
                      alt={prodTitle} 
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />
                    <span className="absolute top-3 left-3 bg-black/80 backdrop-blur-md text-[10px] font-bold px-2.5 py-1 rounded-md text-orange-400 border border-neutral-700">
                      {prodCategory}
                    </span>
                  </div>
                  <div className="p-4">
                    <p className="text-[11px] text-neutral-500 mb-1">{product.location || 'Bukavu, Kivu'}</p>
                    <h3 className="font-bold text-sm mb-3 truncate">{prodTitle}</h3>
                    <div className="flex justify-between items-center">
                      <span className="text-base font-black text-orange-500">{prodPrice}</span>
                      <Link 
                        to={`/products/${product.id}`} 
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                          darkMode ? 'bg-neutral-800 hover:bg-orange-600 hover:text-white text-neutral-200' : 'bg-neutral-100 hover:bg-orange-600 hover:text-white text-neutral-800'
                        }`}
                      >
                        Détails
                      </Link>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}