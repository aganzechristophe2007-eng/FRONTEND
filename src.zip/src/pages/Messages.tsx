import { Link, useNavigate } from 'react-router-dom';
import React, { useEffect, useState } from 'react';
import axios from 'axios';

interface Message {
  id: string;
  content: string;
  createdAt: string;
  sender: { name: string };
}

export default function Messages() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchMessages = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('http://localhost:5000/api/messages', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setMessages(res.data);
      } catch (err: any) {
        setError("Impossible de charger vos messages.");
      } finally {
        setLoading(false);
      }
    };
    fetchMessages();
  }, []);

  if (loading) return <div className="max-w-7xl mx-auto px-4 py-8 text-white">Chargement des messages...</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 text-white">
      <h1 className="text-2xl font-bold mb-6">Mes Messages</h1>
      {error && <p className="text-red-500 mb-4">{error}</p>}
      {messages.length === 0 ? (
        <p className="text-neutral-400">Aucun message pour le moment.</p>
      ) : (
        <div className="space-y-4">
          {messages.map((msg) => (
            <div key={msg.id} className="bg-neutral-900 border border-neutral-800 p-4 rounded-xl">
              <p className="text-sm font-semibold text-primary-400">{msg.sender.name}</p>
              <p className="mt-1">{msg.content}</p>
              <span className="text-xs text-neutral-500">{new Date(msg.createdAt).toLocaleString()}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}