import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, X, Clock, ArrowLeft, PlusCircle, CheckCircle2, Sparkles, Tag, DollarSign } from 'lucide-react';
import { apiFetch } from '../api/client'; // <-- Import de votre client.ts (ajustez le chemin si nécessaire)

const EXCHANGE_RATE = 2300; // 1 USD = 2300 CDF

interface Category {
  id: string;
  name: string;
}

export default function CreateProduct() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const [postType, setPostType] = useState<'SALE' | 'REQUEST'>('SALE');
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  
  const [categories, setCategories] = useState<Category[]>([]);
  const [categoryId, setCategoryId] = useState('');
  
  const [currency, setCurrency] = useState<'USD' | 'CDF'>('USD');
  const [amountInput, setAmountInput] = useState('');
  const [priceUSD, setPriceUSD] = useState(0);
  const [priceCDF, setPriceCDF] = useState(0);
  
  const [itemState, setItemState] = useState('NEW');
  const [durationMode, setDurationMode] = useState<'FREE_24H' | 'EXTENDED'>('FREE_24H');

  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login?redirect=/create-product');
      return;
    }

    const fetchCategories = async () => {
      try {
        const data = await apiFetch('/categories');
        const list = Array.isArray(data) ? data : (data.data || []);
        if (list.length > 0) {
          setCategories(list);
          setCategoryId(list[0].id);
        }
      } catch (err) {
        console.warn("Chargement des catégories ignoré ou indisponible.");
      }
    };

    fetchCategories();
  }, [navigate]);

  const handleAmountChange = (value: string) => {
    setAmountInput(value);
    const num = parseFloat(value) || 0;
    if (currency === 'USD') {
      setPriceUSD(num);
      setPriceCDF(num * EXCHANGE_RATE);
    } else {
      setPriceCDF(num);
      setPriceUSD(num / EXCHANGE_RATE);
    }
  };

  const toggleCurrency = (newCurrency: 'USD' | 'CDF') => {
    setCurrency(newCurrency);
    const num = parseFloat(amountInput) || 0;
    if (newCurrency === 'USD') {
      setPriceUSD(num);
      setPriceCDF(num * EXCHANGE_RATE);
    } else {
      setPriceCDF(num);
      setPriceUSD(num / EXCHANGE_RATE);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const token = localStorage.getItem('token');
    if (!token) {
      setError("Session expirée ou non reconnue. Veuillez vous reconnecter.");
      setLoading(false);
      navigate('/login');
      return;
    }

    if (durationMode === 'EXTENDED') {
      const pendingData = {
        type: postType,
        title: postType === 'REQUEST' ? `[DEMANDE] ${title}` : title,
        description,
        ...(categoryId && { categoryId }),
        images: imagePreview ? [imagePreview] : [],
        priceUSD: Number(priceUSD.toFixed(2)),
        priceCDF: Number(priceCDF.toFixed(2)),
        state: itemState,
        durationMode: 'EXTENDED'
      };
      localStorage.setItem('pending_product', JSON.stringify(pendingData));
      navigate('/checkout');
      return;
    }

    try {
      const now = new Date();
      const expiresAt = new Date(now.getTime() + 24 * 60 * 60 * 1000);

      const payload: Record<string, any> = {
        type: postType,
        title: postType === 'REQUEST' ? `[DEMANDE] ${title}` : title,
        description,
        images: imagePreview ? [imagePreview] : [],
        durationMode,
        expiresAt: expiresAt.toISOString(),
        priceUSD: Number(priceUSD.toFixed(2)),
        priceCDF: Number(priceCDF.toFixed(2)),
        ...(postType === 'SALE' && {
          state: itemState,
          isSold: false
        })
      };

      if (categoryId) {
        payload.categoryId = categoryId;
      }

      // Utilisation directe de votre apiFetch (qui gère l'URL de base et le token)
      await apiFetch('/products', {
        method: 'POST',
        body: JSON.stringify(payload),
      });

      setSuccess(true);
      setTimeout(() => {
        navigate(postType === 'REQUEST' ? '/admin/dashboard' : '/products');
      }, 1500);

    } catch (err: any) {
      setError(err.message || "Une erreur est survenue.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-slate-100 py-10 px-4 flex items-center justify-center relative overflow-hidden selection:bg-orange-500 selection:text-white" style={{ perspective: '1200px' }}>
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-gradient-to-br from-orange-600/15 via-amber-600/5 to-transparent rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 right-10 w-[400px] h-[400px] bg-orange-500/5 rounded-full blur-[100px] pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, y: 24, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="max-w-xl w-full bg-slate-900/85 backdrop-blur-xl border border-slate-800/80 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/50 relative z-10"
      >
        <div className="flex justify-between items-center mb-6 pb-4 border-b border-slate-800/80">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-br from-orange-500/20 to-orange-600/10 text-orange-500 rounded-2xl border border-orange-500/20 shadow-inner">
              <PlusCircle className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base sm:text-lg font-black tracking-tight text-white">
                {postType === 'SALE' ? 'Mettre un article en vente' : 'Formuler une recherche'}
              </h1>
              <p className="text-xs text-slate-400">Publiez instantanément sur le réseau CBFSOKO</p>
            </div>
          </div>
          <Link 
            to="/" 
            className="text-slate-400 hover:text-white text-xs font-semibold flex items-center gap-1.5 bg-slate-800/50 hover:bg-slate-800 px-3 py-2 rounded-xl transition border border-slate-700/50"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Retour
          </Link>
        </div>

        <div className="grid grid-cols-2 gap-2 mb-6 p-1 bg-slate-950/80 rounded-2xl border border-slate-800/80">
          <button
            type="button"
            onClick={() => setPostType('SALE')}
            className={`py-2.5 rounded-xl font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2 ${
              postType === 'SALE' 
                ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow-lg shadow-orange-600/25 border border-orange-500/30' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Tag className="w-3.5 h-3.5" /> Mise en vente
          </button>
          <button
            type="button"
            onClick={() => setPostType('REQUEST')}
            className={`py-2.5 rounded-xl font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2 ${
              postType === 'REQUEST' 
                ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow-lg shadow-orange-600/25 border border-orange-500/30' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" /> Recherche (Demande)
          </button>
        </div>

        {error && (
          <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} className="mb-5 p-3.5 bg-red-500/10 text-red-400 border border-red-500/20 rounded-xl text-xs flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" /> {error}
          </motion.div>
        )}
        
        {success && (
          <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} className="mb-5 p-3.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-xl text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> Publication enregistrée avec succès. Redirection...
          </motion.div>
        )}

        <AnimatePresence mode="wait">
          <motion.form 
            key={postType}
            initial={{ rotateY: 90, opacity: 0 }}
            animate={{ rotateY: 0, opacity: 1 }}
            exit={{ rotateY: -90, opacity: 0 }}
            transition={{ duration: 0.35, ease: "easeInOut" }}
            onSubmit={handleSubmit} 
            className="space-y-4"
            style={{ transformStyle: 'preserve-3d' }}
          >
            <div>
              <label className="block text-[11px] text-slate-400 font-bold uppercase tracking-wider mb-1.5">
                {postType === 'SALE' ? "Titre de l'article" : "Intitulé de la recherche"}
              </label>
              <input 
                type="text" 
                required 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={postType === 'SALE' ? "Ex: Infinix Hot 30 128Go original" : "Ex: Recherche local commercial à Ibanda"}
                className="w-full bg-slate-950/70 border border-slate-800 rounded-xl px-4 py-3 text-white placeholder-slate-600 focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 outline-none transition text-xs sm:text-sm font-medium"
              />
            </div>

            <div className="space-y-3 p-4 bg-slate-950/60 border border-slate-800/80 rounded-2xl">
              <div className="flex justify-between items-center">
                <label className="block text-[11px] text-slate-300 font-bold uppercase tracking-wider flex items-center gap-1.5">
                  <DollarSign className="w-3.5 h-3.5 text-orange-500" /> {postType === 'SALE' ? "Prix de vente" : "Budget estimé (Optionnel)"}
                </label>
                <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800">
                  <button
                    type="button"
                    onClick={() => toggleCurrency('USD')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                      currency === 'USD' ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    USD ($)
                  </button>
                  <button
                    type="button"
                    onClick={() => toggleCurrency('CDF')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                      currency === 'CDF' ? 'bg-orange-600 text-white shadow-md shadow-orange-600/30' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    CDF (FC)
                  </button>
                </div>
              </div>

              <div className="relative">
                <input 
                  type="number" 
                  step="any"
                  value={amountInput}
                  onChange={(e) => handleAmountChange(e.target.value)}
                  placeholder={currency === 'USD' ? "Ex: 185" : "Ex: 425500"}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-4 pr-16 py-3 text-white placeholder-slate-600 focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 outline-none text-sm font-bold tracking-wide"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-orange-500 text-xs font-extrabold uppercase">
                  {currency}
                </span>
              </div>

              <div className="flex justify-between items-center text-[11px] text-slate-400 pt-2 border-t border-slate-900">
                <span className="text-slate-500">Taux indicatif : 1 USD = 2300 CDF</span>
                <span className="font-bold text-slate-200 bg-slate-900 px-2 py-1 rounded-lg border border-slate-800">
                  {currency === 'USD' ? `≈ ${priceCDF.toLocaleString()} FC` : `≈ ${priceUSD.toFixed(2)} $`}
                </span>
              </div>
            </div>

            {postType === 'SALE' && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}>
                <label className="block text-[11px] text-slate-400 font-bold uppercase tracking-wider mb-1.5">État de l'article</label>
                <select 
                  value={itemState}
                  onChange={(e) => setItemState(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-800 rounded-xl px-4 py-3 text-white focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 outline-none text-xs sm:text-sm transition cursor-pointer font-medium"
                >
                  <option value="NEW">Neuf (Jamais utilisé, emballé)</option>
                  <option value="USED">Occasion (Bon état, testé)</option>
                </select>
              </motion.div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] text-slate-400 font-bold uppercase tracking-wider mb-1.5">Catégorie (Optionnel)</label>
                <select 
                  value={categoryId}
                  onChange={(e) => setCategoryId(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-800 rounded-xl px-4 py-3 text-white focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 outline-none text-xs sm:text-sm transition cursor-pointer font-medium"
                >
                  <option value="">Général / Non spécifié</option>
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-[11px] text-slate-400 font-bold uppercase tracking-wider mb-1.5">
                  Illustration
                </label>
                {imagePreview ? (
                  <div className="relative h-[46px] bg-slate-950 border border-slate-800 rounded-xl flex items-center px-3 justify-between">
                    <span className="text-xs text-emerald-400 font-medium truncate flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Image chargée
                    </span>
                    <button type="button" onClick={() => { setImageFile(null); setImagePreview(''); }} className="text-slate-400 hover:text-white bg-slate-800 p-1 rounded-lg transition cursor-pointer">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <label className="w-full h-[46px] border border-dashed border-slate-700 hover:border-orange-500 bg-slate-950/70 rounded-xl flex items-center justify-center gap-2 cursor-pointer transition group">
                    <Upload className="w-4 h-4 text-slate-400 group-hover:text-orange-500 transition" />
                    <span className="text-xs text-slate-400 group-hover:text-white transition font-medium">Ajouter</span>
                    <input type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
                  </label>
                )}
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 font-bold uppercase tracking-wider mb-1.5">Description détaillée</label>
              <textarea 
                rows={3}
                required 
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder={postType === 'SALE' ? "Précisez les spécifications techniques, l'état global..." : "Décrivez précisément vos critères..."}
                className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-4 text-white placeholder-slate-600 focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 outline-none resize-none text-xs sm:text-sm transition font-medium"
              />
            </div>

            <div className="p-4 bg-slate-950/60 border border-slate-800/80 rounded-2xl space-y-3">
              <div className="flex items-center gap-2 text-slate-300 text-[11px] font-bold uppercase tracking-wider">
                <Clock className="w-4 h-4 text-orange-500" /> Durée de visibilité de l'annonce
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setDurationMode('FREE_24H')}
                  className={`p-3 rounded-xl border text-left transition cursor-pointer relative overflow-hidden ${
                    durationMode === 'FREE_24H' 
                      ? 'bg-slate-900 border-orange-500 text-white shadow-md shadow-orange-500/10' 
                      : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="font-bold text-xs">Standard (24h)</div>
                  <div className="text-[10px] text-orange-400 font-semibold mt-0.5">Gratuit</div>
                </button>

                <button
                  type="button"
                  onClick={() => setDurationMode('EXTENDED')}
                  className={`p-3 rounded-xl border text-left transition cursor-pointer relative overflow-hidden ${
                    durationMode === 'EXTENDED' 
                      ? 'bg-slate-900 border-orange-500 text-white shadow-md shadow-orange-500/10' 
                      : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="font-bold text-xs">7 Jours (Illimité)</div>
                  <div className="text-[10px] text-amber-400 font-semibold mt-0.5">Option payante</div>
                </button>
              </div>
            </div>
     
            <button 
              type="submit" 
              disabled={loading}
              className="w-full bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-extrabold py-3.5 rounded-xl transition shadow-lg shadow-orange-600/30 cursor-pointer disabled:opacity-50 text-xs sm:text-sm flex items-center justify-center gap-2 active:scale-[0.99]"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                  Traitement en cours...
                </span>
              ) : (
                durationMode === 'EXTENDED' ? 'Procéder au paiement sécurisé' : 'Publier l\'annonce gratuitement'
              )}
            </button>
          </motion.form>
        </AnimatePresence>
      </motion.div>
    </div>
  );
}