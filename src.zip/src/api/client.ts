const API_URL =
  (import.meta as ImportMeta & { env: { VITE_API_URL?: string } }).env.VITE_API_URL ||
  'http://localhost:5000';

export async function apiFetch(endpoint: string, options: RequestInit = {}) {
  let token = localStorage.getItem('token');
  
  // Nettoyage strict des éventuels guillemets superflus stockés par erreur
  if (token) {
    token = token.replace(/^"(.*)"$/, '$1');
  }

  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  const formattedEndpoint = endpoint.startsWith('/api') 
    ? endpoint 
    : `/api${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`;

  const response = await fetch(`${API_URL}${formattedEndpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error?.message || data.message || 'Une erreur est survenue');
  }

  return data;
}